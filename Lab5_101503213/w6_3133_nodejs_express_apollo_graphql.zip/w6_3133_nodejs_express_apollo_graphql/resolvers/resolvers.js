// In-memory movie data (temporary storage for lab)
let movies = [
  {
    id: "1",
    name: "Inception",
    director_name: "Christopher Nolan",
    production_house: "Warner Bros.",
    release_date: "2010-07-16",
    rating: 8.8
  }
];

// Optional static class for director query requirement
class Movie {
  static getByDirectorName(movies, directorName) {
    const name = directorName.trim().toLowerCase();
    return movies.filter(
      (m) => m.director_name.toLowerCase() === name
    );
  }
}

const movieResolvers = {
  Query: {
    getAllMovies: () => movies,

    getMovieById: (_, { id }) =>
      movies.find((m) => m.id === String(id)),

    getMoviesByDirector: (_, { director_name }) =>
      Movie.getByDirectorName(movies, director_name)
  },

  Mutation: {
    addMovie: (_, { input }) => {
      const newMovie = {
        id: String(Date.now()),
        ...input,
        rating: Number(input.rating)
      };
      movies.push(newMovie);
      return newMovie;
    },

    updateMovie: (_, { id, input }) => {
      const index = movies.findIndex(
        (m) => m.id === String(id)
      );
      if (index === -1) return null;

      movies[index] = {
        ...movies[index],
        ...input,
        rating:
          input.rating !== undefined
            ? Number(input.rating)
            : movies[index].rating
      };

      return movies[index];
    },

    deleteMovieById: (_, { id }) => {
      const beforeLength = movies.length;
      movies = movies.filter((m) => m.id !== String(id));
      return movies.length < beforeLength;
    }
  }
};

export default movieResolvers;